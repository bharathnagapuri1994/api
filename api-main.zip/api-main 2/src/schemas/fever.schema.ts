import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type FeverDocument = HydratedDocument<Fever>;

@Schema()
export class Fever {
  @Prop({required: true})
  name: string;

  @Prop({required: true})
  symptoms: string;
}

export const FeverSchema = SchemaFactory.createForClass(Fever);