import { Model, Types } from "mongoose";
import { Injectable } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Fever } from "src/schemas/fever.schema";

@Injectable()
export class SymptomsService {
  constructor(@InjectModel(Fever.name) private feverModel: Model<Fever>) {}

  async findAll(): Promise<Fever[]> {
    return await this.feverModel.find().exec();
  }

  async findOne(id: string): Promise<Fever> {
    return await this.feverModel
      .findOne({ _id: new Types.ObjectId(id) })
      .exec();
  }

  async add(name: string, symptoms: string) {
    const newFever = new this.feverModel({ name, symptoms });
    return await newFever.save();
  }

  async remove(id: string) {
    return await this.feverModel.deleteOne({ _id: new Types.ObjectId(id) });
  }

  async update(id: string, name: string, symptoms: string){
    let oldFever = await this.findOne(id);
    console.log(oldFever)
    if (name) {
      oldFever["name"] = name;
    }
    if (symptoms) {
      oldFever["symptoms"] = symptoms;
    }

    return await new this.feverModel(oldFever).save();
  }
}
