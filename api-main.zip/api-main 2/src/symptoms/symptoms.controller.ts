import {
  Controller,
  Delete,
  Get,
  Patch,
  Post,
  Param,
  Body,
} from "@nestjs/common";
import { SymptomsService } from "./symptoms.service";

@Controller("main")
//localhost:3000/Main
export class SymptomsController {
  constructor(private readonly symptomsService: SymptomsService) {}
  //localhost:3000/Main/fever

  @Get('')
  async getAll1() {
    return await this.symptomsService.findAll();
  }

  @Get("fever")
  async getAll() {
    return await this.symptomsService.findAll();
  }

  @Get("fever/:id")
  async fetchOne(@Param("id") id: string) {
    return await this.symptomsService.findOne(id);
  }

  @Delete("fever/:id")
  async deleteService(@Param("id") id: string) {
    return await this.symptomsService.remove(id);
  }

  @Patch("fever/:id")
  async updateService(
    @Param("id") id: string,
    @Body("name") name: string,
    @Body("symptoms") symptoms: string
  ) {
    return this.symptomsService.update(id, name, symptoms);
  }

  @Post("fever")
  async addService(
    @Body("name") name: string,
    @Body("symptoms") symptoms: string
  ) {
    return await this.symptomsService.add(name, symptoms);
  }

  @Get("*")
  invalidUrl(){
    return "<h1>The url you have entered is invalid.</h1>";
  }
}
