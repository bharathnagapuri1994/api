import { Module } from "@nestjs/common";
import { SymptomsController } from "./symptoms.controller";
import { SymptomsService } from "./symptoms.service";
import { MongooseModule } from "@nestjs/mongoose";
import { Fever, FeverSchema } from "src/schemas/fever.schema";

@Module({
    imports: [MongooseModule.forFeature([{ name: Fever.name, schema: FeverSchema }])],
    controllers:[SymptomsController],
    providers:[SymptomsService]
})
export class SymptomsModule{}